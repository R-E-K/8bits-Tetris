Thank you for downloading my game !

================================================

If the game doesn't work, you probably need to install the Visual C++ Redistributable for Visual Studio 2015.
You can found it on the "redist" folder. (vc_redist.x86.exe)

================================================

Font used in the game : Upheaval by Brian Kent (http://www.dafont.com/fr/upheaval.font)
Button and keyboard icons are from : http://thoseawesomeguys.com/prompts
Everything else is done by myself. The purpose of making this game was to learn C++.

Are you a programmer ? You can check the source code at : https://github.com/R-E-K/8bits-Tetris

================================================

Playable on keyboard or with XInput Gamepad (Pad Xbox 360, Pad Xbox One)
IMPORTANT : The game is designed to be played with a controller.

How to play (Keyboard / Gamepad) :
- Menu selection : Enter / A
- Menu back : backspace / B
- Open/Close Menu (Pause) : Esc / Start
- Rotate tetromino to left : X / X
- Rotate tetromino to right : C / A
- Moving down tetromino faster : Down Arrow / Down